import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

import ContactUs from './contact/index'

export default  function App() {
  return (
   <ContactUs/>
  );
}