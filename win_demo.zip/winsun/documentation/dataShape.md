# Form Submission - shape of data
```javascript
Submission: {
    name: string,
    email: string,
    phoneNumber: string,
    message: string,
    zipcode: string
}
```
